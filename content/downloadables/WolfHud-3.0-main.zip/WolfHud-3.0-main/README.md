# WolfHud-3.0
## W.I.P, feel free to report any bugs you may encounter

--------------------------
WolfHud largely takes ideas from a few popular huds, such as solarlighthud, voidhud and ahud. If you like the look of my HUD, be sure to check these other HUDs out, as they are actually good.
